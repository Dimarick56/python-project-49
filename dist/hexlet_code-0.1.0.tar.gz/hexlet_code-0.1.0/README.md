### Hexlet tests and linter status:
[![Actions Status](https://github.com/Dimarick56/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Dimarick56/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/0baa56a2c9efaddbc243/maintainability)](https://codeclimate.com/github/Dimarick56/python-project-49/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/0baa56a2c9efaddbc243/test_coverage)](https://codeclimate.com/github/Dimarick56/python-project-49/test_coverage)
