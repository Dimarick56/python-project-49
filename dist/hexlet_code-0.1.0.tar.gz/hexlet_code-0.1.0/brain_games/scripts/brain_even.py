#!/usr/bin/env python3

from brain_games import play_even


def main():

    play_even.even_game()


if __name__ == "__main__":

    main()
